import React from "react"
function AdsBanner() {
  return <div></div>
}

export default AdsBanner
