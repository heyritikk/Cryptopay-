/* eslint-disable no-undef */
import abi from './Transactions.json'
export const contractAddress = '0x85b26Ac3AE4DCD10fbAd15988e250E4259E8Bbe9'
export const contractAbi = abi.abi