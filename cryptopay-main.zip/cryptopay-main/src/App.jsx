import React from "react"
const App = () => <div className={styles.wrapper}></div>

export default App
